#!/bin/bash
cd /opt/adb-appmanager-gui
exec python3 -m android_manager.main "$@"
